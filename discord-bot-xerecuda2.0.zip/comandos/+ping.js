exports.run = (client, msg, args) =>{

msg.channel.send('pong!');

}